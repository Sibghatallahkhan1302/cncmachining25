<?php
// Security headers (optional but good practice)
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: no-referrer-when-downgrade');
header('X-XSS-Protection: 0');
?>

<?php echo file_get_contents('index.html'); ?>
